def main():
    print("Hello from mcp-project!")


if __name__ == "__main__":
    main()
